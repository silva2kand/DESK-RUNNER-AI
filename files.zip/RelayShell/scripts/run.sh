#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."

export PROJECT_ROOT="$(pwd)"

python -m src.relay &

start_mod() {
    python -m "src.$1" &
    echo $! > "tmp/$1.pid"
}

mkdir -p tmp

for mod in voice_loop clipboard_bridge error_scanner ai_researcher injector test_runner deployer; do
    start_mod "$mod"
done

echo "🚀 RelayShell is up! Speak in Tamil/English."
echo "Press Ctrl‑C to shut down."

trap "echo; echo 'Shutting down…'; kill \$(cat tmp/*.pid); rm -rf tmp; exit 0" INT
wait