import hashlib, json, os
from pathlib import Path
from utils.config import load_yaml

def _fingerprint_pubkey(pub_key_path: Path) -> str:
    pub_bytes = pub_key_path.read_bytes()
    return hashlib.sha256(pub_bytes).hexdigest()

def check_owner() -> bool:
    policy = load_yaml(Path("config/policy.yaml"))
    allowed_fp = policy.get("owner_fingerprint")
    if not allowed_fp:
        return False
    priv = Path.home() / ".relay_shell" / "id_rsa.pub"
    if not priv.exists():
        return False
    fp = _fingerprint_pubkey(priv)
    return fp == allowed_fp