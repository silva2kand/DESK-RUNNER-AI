import yaml
from pathlib import Path

def load_yaml(p: Path):
    with p.open("r") as f:
        return yaml.safe_load(f)