import json, hashlib
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from pathlib import Path
import os, time

class Journal:
    def __init__(self, log_dir: Path):
        self.log_dir = log_dir
        self.log_dir.mkdir(parents=True, exist_ok=True)
        self.key_path = Path.home() / ".relay_shell" / "journal_key"
        self.key = self._load_key()

    def _load_key(self):
        if not self.key_path.exists():
            key = AESGCM.generate_key(bit_length=256)
            self.key_path.parent.mkdir(parents=True, exist_ok=True)
            self.key_path.write_bytes(key)
            os.chmod(self.key_path, 0o600)
            return key
        return self.key_path.read_bytes()

    def append(self, topic: str, payload: dict, prev_hash: str):
        entry = {
            "ts": time.time(),
            "topic": topic,
            "payload": payload,
            "prev_hash": prev_hash
        }
        raw = json.dumps(entry, sort_keys=True).encode()
        entry_hash = hashlib.sha256(raw).hexdigest()
        entry["hash"] = entry_hash

        aes = AESGCM(self.key)
        nonce = bytes.fromhex(entry_hash[:24])
        ct = aes.encrypt(nonce, json.dumps(entry).encode(), None)

        filename = self.log_dir / f"{int(entry['ts'])}_{topic}.log"
        with open(filename, "wb") as f:
            f.write(nonce + ct)