import json, threading, zmq, time, requests

ctx = zmq.Context()
pub = ctx.socket(zmq.PUB)
pub.connect("tcp://127.0.0.1:5555")
sub = ctx.socket(zmq.SUB)
sub.connect("tcp://127.0.0.1:5556")
sub.setsockopt(zmq.SUBSCRIBE, b'fix_req')

def call_ollama(prompt):
    url = "http://localhost:11434/api/generate"
    payload = {"model": "llama2", "prompt": prompt}
    try:
        r = requests.post(url, json=payload, timeout=30)
        r.raise_for_status()
        return r.json().get("response", ""), 1
    except Exception as e:
        return f"Failed: {e}", 0

def call_gpt4all(prompt):
    url = "http://localhost:5000/v1/chat/completions"
    payload = {"model": "gpt4all-j", "messages": [{"role": "user", "content": prompt}]}
    try:
        r = requests.post(url, json=payload, timeout=30)
        r.raise_for_status()
        return r.json()["choices"][0]["message"]["content"], 1
    except Exception as e:
        return f"Failed: {e}", 0

def call_fastapi(prompt):
    url = "http://localhost:8000/ai"
    payload = {"prompt": prompt}
    try:
        r = requests.post(url, json=payload, timeout=30)
        r.raise_for_status()
        return r.json().get("answer", ""), 1
    except Exception as e:
        return f"Failed: {e}", 0

def call_free_api(prompt):
    url = "https://api.publicai.site/chat"
    payload = {"message": prompt}
    try:
        r = requests.post(url, json=payload, timeout=30)
        r.raise_for_status()
        return r.json().get("reply", ""), 1
    except Exception as e:
        return f"Failed: {e}", 0

PROVIDERS = {
    "ollama": call_ollama,
    "gpt4all": call_gpt4all,
    "fastapi": call_fastapi,
    "freeapi": call_free_api,
}

def rank_responses(resps):
    best = max(resps.items(), key=lambda x: len(x[1][0]))
    return {"solution": best[1][0], "confidence": 1.0, "provider": best[0]}

def handle_fix_req():
    while True:
        topic, raw = sub.recv_multipart()
        data = json.loads(raw.decode())
        error_msg = data.get("error", "")
        prompt = f"Give a minimal code fix for: {error_msg}"
        responses = {name: fn(prompt) for name, fn in PROVIDERS.items()}
        best = rank_responses(responses)
        pub.send_multipart([b'fix_resp', json.dumps(best).encode()])

threading.Thread(target=handle_fix_req, daemon=True).start()
while True:
    time.sleep(10)