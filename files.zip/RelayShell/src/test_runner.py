import json, threading, zmq, subprocess, os, time

ctx = zmq.Context()
pub = ctx.socket(zmq.PUB)
pub.connect("tcp://127.0.0.1:5555")
sub = ctx.socket(zmq.SUB)
sub.connect("tcp://127.0.0.1:5556")
sub.setsockopt(zmq.SUBSCRIBE, b'run_test')

def run_cmd(cmd):
    proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    out, _ = proc.communicate()
    rc = proc.returncode
    return rc, out[:2000]

def listener():
    while True:
        topic, raw = sub.recv_multipart()
        data = json.loads(raw.decode())
        cmd = data.get("cmd", "pytest -q")
        rc, out = run_cmd(cmd)
        pub.send_multipart([b'test_result', json.dumps({"rc": rc, "out": out}).encode()])

threading.Thread(target=listener, daemon=True).start()
while True:
    time.sleep(10)