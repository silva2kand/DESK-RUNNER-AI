import os, json, threading, time
import sounddevice as sd
import numpy as np
import whisper
import zmq
from pathlib import Path
from utils.config import load_yaml

persona = load_yaml(Path("config/persona.yaml"))
model = whisper.load_model("base")

ctx = zmq.Context()
pub = ctx.socket(zmq.PUB)
pub.connect("tcp://127.0.0.1:5555")
sub = ctx.socket(zmq.SUB)
sub.connect("tcp://127.0.0.1:5556")
sub.setsockopt(zmq.SUBSCRIBE, b'voice')

def dummy_voice_input():
    while True:
        text = input("Speak (type) > ")
        payload = json.dumps({"lang": "en", "text": text}).encode()
        pub.send_multipart([b'voice', payload])
        time.sleep(1)

def tts_worker():
    while True:
        topic, raw = sub.recv_multipart()
        if topic == b'voice':
            payload = json.loads(raw.decode())
            print(f"TTS Output: {payload.get('text')} [{payload.get('lang')}]")
            # [TODO] Integrate with Piper or other TTS engine

threading.Thread(target=dummy_voice_input, daemon=True).start()
threading.Thread(target=tts_worker, daemon=True).start()

while True:
    time.sleep(10)