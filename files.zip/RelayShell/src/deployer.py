import yaml, json, subprocess, threading, zmq, os
from pathlib import Path

ctx = zmq.Context()
pub = ctx.socket(zmq.PUB)
pub.connect("tcp://127.0.0.1:5555")
sub = ctx.socket(zmq.SUB)
sub.connect("tcp://127.0.0.1:5556")
sub.setsockopt(zmq.SUBSCRIBE, b'deploy')

manifest = yaml.safe_load(Path("config/apps.yaml").read_text())

def exec_cmd(cmd):
    return subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)

def handle():
    while True:
        topic, raw = sub.recv_multipart()
        req = json.loads(raw.decode())
        svc = req.get("service")
        act = req.get("action")
        if svc not in manifest["services"]:
            pub.send_multipart([b'log', json.dumps({"level": "error", "msg": f"unknown service {svc}"}).encode()])
            continue
        entry = manifest["services"][svc]
        if act == "start":
            p = exec_cmd(entry["start_cmd"])
            pub.send_multipart([b'log', json.dumps({"level": "info", "msg": f"started {svc}, pid={p.pid}"}).encode()])
        elif act == "stop":
            exec_cmd(entry["stop_cmd"])
            pub.send_multipart([b'log', json.dumps({"level": "info", "msg": f"stopped {svc}"}).encode()])

threading.Thread(target=handle, daemon=True).start()
while True:
    time.sleep(10)