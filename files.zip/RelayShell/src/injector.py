import json, threading, zmq, time, subprocess
from pathlib import Path

ctx = zmq.Context()
pub = ctx.socket(zmq.PUB)
pub.connect("tcp://127.0.0.1:5555")
sub = ctx.socket(zmq.SUB)
sub.connect("tcp://127.0.0.1:5556")
sub.setsockopt(zmq.SUBSCRIBE, b'clipboard')

def edit_vscode(snippet):
    tmp = Path("/tmp/relay_fix.py")
    tmp.write_text(snippet)
    subprocess.run(["code", "--reuse-window", str(tmp)])

def clipboard_listener():
    while True:
        topic, raw = sub.recv_multipart()
        data = json.loads(raw.decode())
        if data.get("action") == "paste":
            snippet = data["payload"]
            try:
                edit_vscode(snippet)
            except Exception:
                pass

threading.Thread(target=clipboard_listener, daemon=True).start()
while True:
    time.sleep(10)