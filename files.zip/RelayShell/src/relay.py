import json
import zmq
import hashlib
import time
from pathlib import Path
from utils.logger import Journal
from utils.rbac import check_owner

TOPICS = [
    b'voice', b'clipboard', b'log', b'fix_req', b'fix_resp', b'run_test', b'test_result', b'deploy'
]

ctx = zmq.Context()
pub = ctx.socket(zmq.PUB)
pub.bind("tcp://127.0.0.1:5555")

sub = ctx.socket(zmq.SUB)
sub.connect("tcp://127.0.0.1:5556")
for topic in TOPICS:
    sub.setsockopt(zmq.SUBSCRIBE, topic)

journal = Journal(Path("journal"))
prev_hash = "0" * 64

def hash_chain(prev_hash: str, payload: bytes) -> str:
    return hashlib.sha256(prev_hash.encode() + payload).hexdigest()

while True:
    try:
        topic, raw = sub.recv_multipart()
        payload = json.loads(raw.decode())
        journal.append(topic.decode(), payload, prev_hash)
        prev_hash = hash_chain(prev_hash, raw)

        if topic == b'voice':
            text = payload.get("text", "")
            if "error" in text.lower() or "crash" in text.lower():
                pub.send_multipart([b'fix_req', json.dumps({"error": text, "lang": payload.get("lang", "en")}).encode()])
        elif topic == b'fix_resp':
            solution = payload.get("solution", "")
            pub.send_multipart([b'clipboard', json.dumps({"action": "paste", "payload": solution}).encode()])
            pub.send_multipart([b'run_test', json.dumps({"cmd": "pytest -q"}).encode()])
        elif topic == b'test_result':
            rc, out = payload.get("rc", 1), payload.get("out", "")
            msg = f"Tests {'passed' if rc == 0 else 'failed'}."
            pub.send_multipart([b'voice', json.dumps({"lang": "en", "text": msg}).encode()])
        elif topic == b'deploy':
            if check_owner():
                pub.send_multipart([b'log', json.dumps({"level": "info", "msg": f"Deploy cmd {payload}"}).encode()])
            else:
                pub.send_multipart([b'log', json.dumps({"level": "warn", "msg": "unauthorized deploy attempt"}).encode()])

    except KeyboardInterrupt:
        break
    except Exception as exc:
        pub.send_multipart([b'log', json.dumps({"level": "error", "msg": str(exc)}).encode()])