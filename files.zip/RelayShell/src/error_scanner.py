import re, json, time, threading, zmq
from pathlib import Path

log_path = Path("journal/app.log")
error_regex = re.compile(r'ERROR\s+(.*)', re.IGNORECASE)

ctx = zmq.Context()
pub = ctx.socket(zmq.PUB)
pub.connect("tcp://127.0.0.1:5555")

def tail_f():
    log_path.touch(exist_ok=True)
    with log_path.open('r') as f:
        f.seek(0,2)
        while True:
            line = f.readline()
            if not line:
                time.sleep(1)
                continue
            m = error_regex.search(line)
            if m:
                payload = {"error_line": line.strip()}
                pub.send_multipart([b'log', json.dumps({"level": "error", "msg": payload}).encode()])
                pub.send_multipart([b'fix_req', json.dumps({"error": line, "lang": "en"}).encode()])

threading.Thread(target=tail_f, daemon=True).start()
while True:
    time.sleep(10)