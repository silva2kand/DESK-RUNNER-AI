import pyperclip, json, threading, time, zmq

ctx = zmq.Context()
pub = ctx.socket(zmq.PUB)
pub.connect("tcp://127.0.0.1:5555")
sub = ctx.socket(zmq.SUB)
sub.connect("tcp://127.0.0.1:5556")
sub.setsockopt(zmq.SUBSCRIBE, b'clipboard')

def paste_worker():
    while True:
        topic, raw = sub.recv_multipart()
        payload = json.loads(raw.decode())
        if payload.get("action") == "paste":
            pyperclip.copy(payload["payload"])
            print(f"Pasted to clipboard: {payload['payload']}")

threading.Thread(target=paste_worker, daemon=True).start()

def monitor_clipboard():
    last = pyperclip.paste()
    while True:
        cur = pyperclip.paste()
        if cur != last:
            pub.send_multipart([b'clipboard', json.dumps({"action": "copy", "payload": cur}).encode()])
            last = cur
        time.sleep(1)

threading.Thread(target=monitor_clipboard, daemon=True).start()

while True:
    time.sleep(10)