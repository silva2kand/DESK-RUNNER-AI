# Desk Runner AI: RelayShell

A modular, production-ready AI debug and deployment shell.  
Supports Ollama, GPT4All, Docker, FastAPI, and free APIs.

## Features

- Voice input (Tamil/English) via Whisper + TTS
- Clipboard and terminal capture
- Multi-LLM querying (Ollama, GPT4All, FastAPI, public APIs)
- Auto-selects, injects, and tests code fixes
- Launch/stop AI services from YAML registry
- RBAC, encrypted journal logging, Docker-ready

## Quick Start

```bash
git clone https://github.com/silva2kand/desk-runner-ai.git
cd desk-runner-ai/RelayShell
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
./scripts/run.sh
```

## Architecture

RelayShell modules are in `src/`, configs in `config/`, and scripts in `scripts/`.  
Add your API keys and model definitions in YAML files.

## Extending

- Add Dockerfiles for any module in `docker/`
- Plug in FastAPI endpoints or additional free/public APIs in `src/ai_researcher.py`
- RBAC and service registry in `config/`

## Security

- Owner-only actions with RSA fingerprint
- All logs encrypted, hash-chained

---

Happy debugging & deploying!